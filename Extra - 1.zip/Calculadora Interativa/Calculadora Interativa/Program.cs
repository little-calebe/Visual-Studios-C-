﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculadora_Interativa
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n1, n2, n3, n4;
            Console.WriteLine("Esse programa foi feito para: \n");
            Console.WriteLine("Você escolher dois números \n");
            Console.WriteLine("E depois fazer uma operação com eles.\n");
            Console.WriteLine("\nDigite o primeiro número: ");
            n1 = int.Parse(Console.ReadLine());
            Console.WriteLine("\nDigite o segundo número: ");
            n2 = int.Parse(Console.ReadLine());
            Console.WriteLine("\n");
            Console.WriteLine("Escolha uma operação para esses dois números: ");
            Console.WriteLine("\n1 - Soma");
            Console.WriteLine("\n2 - Subtração");
            Console.WriteLine("\n3 - Multiplicação");
            Console.WriteLine("\n4 - Divisão");
            Console.WriteLine("\nEscolha de acordo com o número da operação: ");
            n3 = int.Parse(Console.ReadLine());
            n4 = 0;
            if (n3 == 1) { n4 = n1 + n2; }
            if (n3 == 2) { n4 = n1 - n2; }
            if (n3 == 3) { n4 = n1 * n2; }
            if (n3 == 4) { n4 = n1 / n2; }
            Console.WriteLine("\nLogo o resultado da operação dos dois números é: " + n4);
        }
    }
}