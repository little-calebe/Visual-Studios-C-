﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aposentadoria
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n1, n2, n3;
            Console.WriteLine("Qual seu codigo de númeração de empregado?: ");
            n1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Qual sua idade?: ");
            n2 = int.Parse(Console.ReadLine());
            Console.WriteLine("Quantos anos você já trabalhou?: ");
            n3 = int.Parse(Console.ReadLine());
            Console.WriteLine("Esse é seu codigo: "+n1);
            Console.WriteLine("\n");
            if (n2 >= 60 && n3 >= 25) { Console.WriteLine("Você pode se aposentar"); }
            else
            if (n2 >= 65) { Console.WriteLine("Você pode se aposentar: "); }
            else 
            if (n3 >= 30) { Console.WriteLine("Você pode se aposentar: "); }
            else { Console.WriteLine("Você não pode se aposentar");}
        }
    }
}
