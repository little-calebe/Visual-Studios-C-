﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n1, n2, n3;
            Console.WriteLine("Digite um número: ");
            n1 = int.Parse(Console.ReadLine());
            n2 = n1 + 1;
            n3 = n1 - 1;
            Console.WriteLine("Esse é o sucessor desse número: " + n2);
            Console.WriteLine("Esse é o antecessor do seu número: " + n3);
        }
    }
}
