﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _11
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n1;
            Console.WriteLine("Digite um número: ");
            n1 = int.Parse(Console.ReadLine());
            if (n1 < 0) { Console.WriteLine("Esse número é Negativo."); }
            else { Console.WriteLine("Esse número é Positivo."); }
        }
    }
}