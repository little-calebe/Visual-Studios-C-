﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _12
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n1;
            Console.WriteLine("Digite um número: ");
            n1 = int.Parse(Console.ReadLine());
            if (n1 % 2 == 0) { Console.WriteLine("Seu número é par"); }
            else { Console.WriteLine("Seu número é impar");}
        }
    }
}
