﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n1, n2;
            Console.WriteLine("Digite um número: ");
            n1 = int.Parse(Console.ReadLine());
            n2 = n1 * 3;
            Console.WriteLine("Esse é o triplo do seu número: " + n2);
        }
    }
}
