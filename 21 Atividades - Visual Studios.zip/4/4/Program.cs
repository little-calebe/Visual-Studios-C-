﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n1, n2, n3;
            Console.WriteLine("Digite um número: ");
            n1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Digite outro número: ");
            n2 = int.Parse(Console.ReadLine());
            n3 = n1 * n2;
            Console.WriteLine("Essa é a multiplicação dos dois números: " + n3);
        }
    }
}
