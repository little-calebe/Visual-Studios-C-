﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n1, n2;
            Console.WriteLine("Escreva sua idade: ");
            n1 = int.Parse(Console.ReadLine());
            n2 = n1 + 10;
            Console.WriteLine("Essa é sua idade daqui dez anos: " + n2);
        }
    }
}
