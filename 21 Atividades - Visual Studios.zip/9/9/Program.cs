﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n1, n2, n3, media;
            Console.WriteLine("Escreva um número: ");
            n1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Escreva outro número: ");
            n2 = int.Parse(Console.ReadLine());
            Console.WriteLine("Escreva outro número: ");
            n3 = int.Parse(Console.ReadLine());
            media = (n1 + n2 + n3) / 4;
            Console.WriteLine("Essa é a média: " + media);
        }
    }
}
