﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n1, n2;
            Console.WriteLine("Digite um número: ");
            n1 = int.Parse(Console.ReadLine());
            n2 = n1 * 2;
            Console.WriteLine("Esse é o dobro do seu número: " + n2);
        }
    }
}
