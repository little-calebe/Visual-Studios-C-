﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _17
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n1, n2;
            Console.WriteLine("Digite seu salário: ");
            n1 = int.Parse(Console.ReadLine());
            n2 = (int)(n1 * 1.10);
            if (n1 < 2000) { Console.WriteLine("Seu salário é: " + n2);}
            else { Console.WriteLine("Seu salário é: " + n1);}
        }
    }
}
