﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _15
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n1;
            Console.WriteLine("Digite um número: ");
            n1 = int.Parse(Console.ReadLine());
            if (n1 > 100) { Console.WriteLine("Seu número é: " + n1 + " e ele é maior que 100");}
            else { Console.WriteLine("Seu número é: " + n1 + " e ele não é maior que 100");}
        }
    }
}
